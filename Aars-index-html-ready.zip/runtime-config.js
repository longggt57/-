// Public deployment configuration. Never put passwords or API secrets here.
// Empty apiBase: read-only static preview. Configure your server before enabling writes.
// Relative API example: './api/' (includes this GitHub repository's base path).
// Cross-origin APIs additionally require credentialed CORS and compatible authentication.
export const runtime={apiBase:'',signInUrl:'',signOutUrl:''};
